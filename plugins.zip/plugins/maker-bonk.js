import jimp from 'jimp'

let handler = async (m, { conn, text }) => {
	let img = await jimp.read('https://i.imgur.com/nav6WWX.png'),
		who = m.mentionedJid?.[0] || m.quoted?.sender || m.sender,
		avatar = await jimp.read(await conn.profilePictureUrl(who, 'image').catch(_ => 'https://telegra.ph/file/ef91bf0c880ff2dc4077a.jpg')),
		bonk = await img.composite(avatar.resize(128, 128), 120, 90, {
			mode: 'dstOver',
			opacitySource: 1,
			opacityDest: 1
		}).getBufferAsync('image/png')
	conn.sendMessage(m.chat, { image: bonk }, { quoted: m })
}
handler.help = handler.alias = ['bonk']
handler.tags = ['maker']
handler.command = /^(bonk)$/i
handler.limit = true

export default handler
